<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="style3.css">
</head>
<body>
<div class="search-box">
	<input type="text" class="search-txt" placeholder="search here">
	<a href="#" class="search-btn"><i class="fa fa-search" aria-hidden="true"></i></a>
</div>	
</body>
</html>